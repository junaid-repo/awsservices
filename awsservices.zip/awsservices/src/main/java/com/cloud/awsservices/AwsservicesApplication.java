package com.cloud.awsservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AwsservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(AwsservicesApplication.class, args);
	}

}
